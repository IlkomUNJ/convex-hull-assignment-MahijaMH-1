#ifndef SLOWCONVEX_H
#define SLOWCONVEX_H

#include "drawwidget.h"
#include <QWidget>
#include <QVector>

class SlowConvex : public QWidget
{
    Q_OBJECT

public:
    explicit SlowConvex(DrawWidget *canvas, QWidget *parent = nullptr);

    void slowAlgorithm();
    int crossProduct(int Px, int Py, int Qx, int Qy, int Rx, int Ry);

    const QVector<QPair<QPoint,QPoint>>& getResult() const { return m_edges; }
    void clearEdges();

private:
    QVector<QPair<QPoint,QPoint>> m_edges;
    DrawWidget *m_canvas;
};

#endif // SLOWCONVEX_H
