#include "slowconvex.h"
#include <QDebug>

SlowConvex::SlowConvex(DrawWidget *canvas, QWidget *parent)
    : QWidget(parent), m_canvas(canvas)
{}

void SlowConvex::slowAlgorithm()
{
    m_edges.clear();
    int counter = 0;

    const QList<QPoint> pts = m_canvas->getPosition();

    qDebug() << "Total points:" << pts.size();
    for (int i = 0; i < pts.size(); ++i) {
        qDebug() << "P" << i << "=" << pts.at(i);
    }

    // brute-force edge check
    for (int i = 0; i < pts.size(); ++i) {
        for (int j = i + 1; j < pts.size(); ++j) {
            if (pts[i] == pts[j]) continue;

            bool edgeCandidate = true;
            for (int k = 0; k < pts.size(); ++k) {
                if (k == i || k == j) continue;
                ++counter;
                int cp = crossProduct(
                    pts[i].x(), pts[i].y(),
                    pts[j].x(), pts[j].y(),
                    pts[k].x(), pts[k].y()
                );
                if (cp < 0) {
                    edgeCandidate = false;
                    break;
                }
            }
            if (edgeCandidate) {
                m_edges.append(qMakePair(pts[i], pts[j]));
            }
        }
    }

    m_canvas->iterationCount = counter;

    qDebug() << "Hull edges:";
    for (int idx = 0; idx < m_edges.size(); ++idx) {
        qDebug() << idx << ":" << m_edges[idx];
    }

    update();
}

int SlowConvex::crossProduct(int Px, int Py, int Qx, int Qy, int Rx, int Ry)
{
    // determinant (PQ x PR)
    return (Qx - Px) * (Ry - Py) - (Qy - Py) * (Rx - Px);
}

void SlowConvex::clearEdges()
{
    m_edges.clear();
}
